<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/pos_navbar.css">
</head>
<body>
    <nav>
        
        <ul>
            <div class="logo"><img src="../assets/images/logos.png" alt="rdpos logo"></div>
            <div class="navigation">
                <li><a href="pos.php">Pos</a></li>
                <li><a href="transaction.php">Transactions</a></li>
                <li><a href="settings.php">Settings</a></li>
                <li><a href="logout.php">Logout</a></li>
            </div>
        </ul>
    </nav>
</body>
</html>